#pragma once

// Including SDKDDKVer.h defines the highest available Windows platform.

#include <SDKDDKVer.h>
