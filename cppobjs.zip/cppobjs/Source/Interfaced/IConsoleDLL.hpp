// CodeGear C++Builder
// Copyright (c) 1995, 2012 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'IConsoleDLL.pas' rev: 24.00 (Win32)

#ifndef IconsoledllHPP
#define IconsoledllHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Iconsoledll
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TTextColor : unsigned char { tcBLACK, tcBLUE, tcGREEN, tcCYAN, tcRED, tcMAGENTA, tcBROWN, tcLIGHTGRAY, tcDARKGRAY, tcLIGHTBLUE, tcLIGHTGREEN, tcLIGHTCYAN, tcLIGHTRED, tcLIGHTMAGENTA, tcYELLOW, tcWHITE };
#pragma option pop

__interface IConsole;
typedef System::DelphiInterface<IConsole> _di_IConsole;
__interface  INTERFACE_UUID("{9BBDA1A4-21E7-4D11-8F1C-E2AD13D2779C}") IConsole  : public System::IInterface 
{
	
public:
	virtual void __stdcall Reset(void) = 0 ;
	virtual void __stdcall ClearScreen(void) = 0 ;
	virtual void __stdcall GotoXY(int x, int y) = 0 ;
	virtual void __stdcall TextColor(TTextColor newColor) = 0 ;
	virtual void __stdcall TextAttribute(int newAttribute) = 0 ;
	virtual void __stdcall TextBackground(TTextColor newBackground) = 0 ;
	virtual int __stdcall ReadKey(void) = 0 ;
	virtual bool __stdcall KeyPressed(void) = 0 ;
	virtual void __stdcall Write(char * text) = 0 ;
	virtual void __stdcall WriteLn(char * text) = 0 ;
};

//-- var, const, procedure ---------------------------------------------------
extern "C" _di_IConsole __stdcall CreateConsole(void);
}	/* namespace Iconsoledll */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_ICONSOLEDLL)
using namespace Iconsoledll;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// IconsoledllHPP
