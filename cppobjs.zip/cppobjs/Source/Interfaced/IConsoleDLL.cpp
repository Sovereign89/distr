#include <windows.h>
#define ICONSOLEDLL_EXPORT
#include "iconsole.h"
#include "tconsole.h"

HRESULT ICONSOLEDLL_API CreateConsole(IConsole **console)
{
    *console = (IConsole *)(new TConsole());
    if (*console)
    {
        (*console)->AddRef();
        return S_OK;
    }
    else
        return E_NOINTERFACE;
}

int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{
    return 1;
}

