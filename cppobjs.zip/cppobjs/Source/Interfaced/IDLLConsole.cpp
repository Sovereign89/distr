#include <windows.h>
#define ICONSOLEDLL_EXPORT
#include "iconsole.h"
#include "iconsoleimpl.h"

IConsole * ICONSOLEDLL_API CreateConsole()
{
    return (IConsole *)(new IConsoleImpl());
}

int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{
    return 1;
}

