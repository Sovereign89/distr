
Chilkat Delphi DLL API for Embarcadero� Delphi
----------------------------------------------------

See http://www.chilkatsoft.com/delphiDll.asp for information about getting started.

----------------------------------------
Online Documentation, Code Samples, etc.
----------------------------------------

Reference Documentation:  http://www.chilkatsoft.com/refdoc/dd.asp
Example Code: http://www.example-code.com/delphiDll/default.asp
Chilkat Blog (FAQ):  http://www.cknotes.com/
Purchase URL: http://www.chilkatsoft.com/purchase2.asp










-------------------------------------------------------------------
C++Builder is a registered trademark of Embarcadero Technologies.
Embarcadero is a registered trademark of Embarcadero Technologies. 
