# HeaderParser
This is a simple console utility that can convert C/C++ headers to Pascal sources compatible with Delphi and FreePascal/Lazarus.
